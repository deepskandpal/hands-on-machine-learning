import requests
import json
import asyncio
from concurrent.futures import ThreadPoolExecutor
import os


class Status:

    def __init__(self, config, status, master, model_info, logs, rid):
        """

        :param config:
        :param status:
        :param master:
        :param model_info:
        """
        self.config = config
        self.final_response = []
        self.master = master
        self.response = status
        self.model = model_info
        self.logs = logs
        self.rid = rid

    def fetch_response(self, session, url, auth):
        """
        request making method, given a set of parameters makes a http request and gets the response
        :param session:
        :param url:
        :param auth:
        :return: returns API response
        """
        try:
            with session.get(url, headers={'Authorization': auth}) as response:

                if response.status_code == 200:
                    data = json.loads(response.text)
                else:
                    data = {"Error": response.text}
                return {'code': response.status_code, 'response': data}
        except Exception as e:
            print(e)
            return {'code': '500', 'response': 'internal server error : ' + str(e)}

    def create_requests(self, response):
        """

        :param response:
        :return:
        """
        status_apis = []
        intent_url = self.config.get("intent").get("status")
        intent_id = response.get('task_id')
        intent_auth = self.config.get("intent").get("authorization")
        intent_url = os.path.join(str(intent_url), intent_id)
        intent_request = {
                            "url": intent_url,
                            "auth": intent_auth,
                         }
        self.logs.info("Rid:%s; intent request:%s", self.rid, json.dumps(intent_request))
        status_apis.append(intent_request)
        ner = response.get('ner')
        if ner is not None:
            ner_id = response.get('ner').get('task_id')
            ner_auth = self.config.get("ner").get("authorization")
            ner_url = self.config.get("ner").get("status")
            ner_url = os.path.join(str(ner_url), ner_id)
            ner_request = {
                            "url": ner_url,
                            "auth": ner_auth,
                            }
            self.logs.info("Rid:%s; ner request:%s", self.rid, json.dumps(ner_request))
            status_apis.append(ner_request)
            return status_apis
        else:
            return status_apis

    def make_api_calls(self):
        """
        main function of status class which returns consolidated status for intent and ner
        :param
        :return: A list of consolidated response of statuses from intent and ner status API
        """
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        future = asyncio.ensure_future(self.get_data_asynchronous(self.response))
        loop.run_until_complete(future)
        response, code = self.collate_response(self.final_response)
        self.delete_from_redis(self.master, response)
        return response

    def delete_from_redis(self, master, response):
        """
        deletes the model key from redis DB if success or failure is reported in any of the status API results
        :param master:
        :param response:
        :return:
        """
        states = []
        is_delete_from_redis = False
        intent = response.get("intent")
        ner = response.get("ner")
        if intent is not None:
            intent_state = intent.get("state")
            states.append(intent_state)
        if ner is not None:
            ner_state = ner.get("state")
            states.append(ner_state)
        self.logs.info("Rid:%s; states in status API:%s", self.rid, str(states))
        if any(i in ['FAILURE', 'SUCCESS'] for i in states) and not any(j in ['PROGRESS', 'PENDING'] for j in states):
            model = self.model.get('model')
            lang = self.model.get('lang')
            master.delete('ml_' + model + '_' + lang)
            is_delete_from_redis = True
            self.logs.info("Rid:%s; key deleted from redis API:%s", self.rid, str('ml_' + model + '_' + lang))
            states.clear()
            return is_delete_from_redis
        states.clear()
        return is_delete_from_redis

    async def get_data_asynchronous(self, response):
        """
        calls intent and ner status api in async
        :param response:
        :return: NA
        """
        status_urls = self.create_requests(response)
        with ThreadPoolExecutor(max_workers=10) as executor:
            with requests.Session() as session:
                # Set any session parameters here before calling `fetch`
                loop = asyncio.get_event_loop()
                tasks = [
                    loop.run_in_executor(
                        executor,
                        self.fetch_response,
                        *(session, url.get("url"), url.get("auth"))
                        # Allows us to pass in multiple arguments to `fetch`
                    )
                    for url in status_urls
                ]
                for response in await asyncio.gather(*tasks):
                    self.final_response.append(response)

    def collate_response(self, response_list):
        consolidated_result = {}
        code = 500
        codes = []
        for results in response_list:
            code = results.get('code')
            codes.append(code)
        for result in response_list:
            if all(i in [200] for i in codes):
                consolidated_result.update(result.get('response'))
                code = 200
            else:
                consolidated_result.update(result.get('response'))
                code = 500

        self.logs.info("Rid:%s; consolidated response API:%s", self.rid, json.dumps(consolidated_result))
        # removing extra result key in response
        try:
                temp = consolidated_result.pop("result")
        except:
                pass
        return consolidated_result, code
