import requests
import asyncio
from concurrent.futures import ThreadPoolExecutor
import os
import json
from nfs_operations import TextOperations
from nfs_operations import ZipOperations
from nfs_operations import NfsStorage


DIR_PATH = os.path.dirname(os.path.realpath(__file__))
CONFIG_FILE = os.path.join(DIR_PATH, 'configs', 'config.json')
intent_entity_map_file = os.path.join(DIR_PATH, 'intent_entity_map', 'intent_entity_map.json')
CONFIG = json.load(open(CONFIG_FILE))


class Prediction:

    def __init__(self, config, logs, rid, redis_master, redis_manager, version_file, mongo_manager):
        """
        Initializes the predict object for a prediction request
        :param config:
        :param logs:
        :param rid:
        :param redis_master:
        :param redis_manager:
        """
        self.nfs_storage = NfsStorage()
        self.zip_op = ZipOperations()
        self.redis_manager = redis_manager
        self.redis_master = redis_master
        self.text_object = TextOperations()
        self.config = config
        self.final_response = []
        self.intent_entity_map = {}
        self.logs = logs
        self.rid = rid
        self.version_file = version_file
        self.mongo_manager = mongo_manager

    def fetch_response(self, session, url, auth, param, data):
        """
        request making method, given a set of parameters makes a http request and gets the response
        :param session:
        :param url:
        :param auth:
        :param param:
        :return: returns API response
        """
        print(data)
        try:
            with session.get(url, headers={'Authorization': auth, 'Content-Type': 'application/json'}, params=param, json=data) as response:
                if response.status_code == 200:
                    data = json.loads(response.text)
                else:
                    data = {"Error": response.text}
                return {'code': response.status_code, 'response': data}
        except Exception as e:
            self.logs.info("Rid:%s; internal server error:%s", self.rid, str(e))
            return {'code': '500', 'response': 'internal server error : ' + str(e)}

    def create_requests(self, query, lang, model):
        """
        creates request of intent and NER using params and urls from config and prediction API
        :param query:
        :param lang:
        :param model:
        :return: list of prediction requests of intent and NER
        """
        ner_url = self.config.get("ner").get("prediction")
        ner_auth = self.config.get("ner").get("authorization")
        intent_url = self.config.get("intent").get("prediction")
        intent_auth = self.config.get("intent").get("authorization")
        urls = [
            {
                "url": ner_url,
                "auth": ner_auth,
                "param": {"text": query, "lang": lang, "model": model}
            },
            {
                "url": intent_url,
                "auth": intent_auth,
                "param": {"q": query, "ani": "1", "model": model, "lang": lang}
            }
        ]

        return urls

    async def get_data_asynchronous(self, query, lang, model):
        """
        calls intent and NER predict api in async
        :param query:
        :param lang:
        :param model:
        :return: a list of consolidated results of intent and NER predict APIs
        """
        predict_urls = self.create_requests(query, lang, model)
        with ThreadPoolExecutor(max_workers=10) as executor:
            with requests.Session() as session:
                # Set any session parameters here before calling `fetch`
                loop = asyncio.get_event_loop()
                tasks = [
                    loop.run_in_executor(
                        executor,
                        self.fetch_response,
                        *(session, url.get("url"), url.get("auth"), url.get("param"), url.get("data"))
                        # Allows us to pass in multiple arguments to `fetch`
                    )
                    for url in predict_urls
                ]
                for response in await asyncio.gather(*tasks):
                    self.final_response.append(response)

    def ner_data(self, ongoing_intent, entities):
        if entities is None:
                list_of_intents = self.intent_entity_map.get("intent_entity_map")
                intent_entity_map_dict = next((item for item in list_of_intents if item["intent"] == ongoing_intent), None)
                if intent_entity_map_dict is not None:
                    sample_response = {
                                        "ongoing_intent": ongoing_intent,
                                        "entities": intent_entity_map_dict.get("entities")
                                       }
                    self.logs.info("Rid:%s; ner intent entity map:%s", self.rid, sample_response)
                    return sample_response
                else:
                    sample_response = {
                        "ongoing_intent": ongoing_intent,
                        "entities": []
                        }
                    self.logs.info("Rid:%s; ner intent entity map:%s", self.rid, sample_response)
                    return sample_response
        else:
            sample_response = {
                "ongoing_intent": ongoing_intent,
                "entities": entities
            }
            return sample_response

    def create_ner_request(self, query, lang, model, intent_entity_map):

        ner_url = self.config.get("ner").get("prediction")
        ner_auth = self.config.get("ner").get("authorization")
        if ner_url and ner_auth is not None:
            ner_request = {
                    "url": ner_url,
                    "auth": ner_auth,
                    "param": {"text": query, "lang": lang, "model": model},
                    "data": intent_entity_map
                }
            self.logs.info("Rid:%s; ner request:%s", self.rid, json.dumps(ner_request, ensure_ascii=False))
            return ner_request
        return None

    def call_ner(self, ner_request):

        with requests.Session() as session:
            response = self.fetch_response(session,ner_request.get("url"),
                       ner_request.get("auth"), ner_request.get("param"), ner_request.get("data"))
            return response

    def create_intent_request(self, query, model, lang, special_intent_flag, clean_indicator, greetings_check):

        intent_url = self.config.get("intent").get("prediction")
        intent_auth = self.config.get("intent").get("authorization")
        if intent_url and intent_auth is not None:
            intent_request = {
                "url": intent_url,
                "auth": intent_auth,
                "param": {"q": query, "ani": "1",
                          "model": model, "lang": lang,
                          "special_intents": special_intent_flag,
                          "greetings_check": greetings_check,
                          "clean_indicator": clean_indicator
                          }
            }
            self.logs.info("Rid:%s; intent request:%s", self.rid, json.dumps(intent_request, ensure_ascii=False))
            return intent_request
        return None

    def call_intent(self, intent_request):

        with requests.Session() as session:
            response = self.fetch_response(session, intent_request.get("url"), intent_request.get("auth"), intent_request.get("param"), intent_request.get("data"))
            return response

    def get_intent_for_ner(self, query, lang, model, ongoing_intent, entities, intent_entity_map, clean_indicator, greetings_check):
        """FOR Ongoing intent key in data form of prediction API when it is blank
        Series of methods which will perform the following task"""
        result = {}
        self.intent_entity_map = intent_entity_map
        status_code = 500
        response_list = []
        if entities is None:
            intent_request = self.create_intent_request(query, model, lang, False,
                                                        clean_indicator=clean_indicator, greetings_check=greetings_check)
            intent_response = self.call_intent(intent_request)
            if intent_response.get("code") == 200:
                ongoing_intent = intent_response.get("response").get("textLabel")
                response_list.append(intent_response)
                if ongoing_intent is not None:
                    intent_entity_map = self.ner_data(ongoing_intent, entities)
                    ner_request = self.create_ner_request(query, lang, model, intent_entity_map)
                    ner_response = self.call_ner(ner_request)
                    response_list.append(ner_response)
                    result, status_code = self.collate_response(response_list)
                    self.logs.info("Rid:%s; Response:%s", self.rid, 'intent response: ' + json.dumps(intent_response, ensure_ascii=False))
                    self.logs.info("Rid:%s; Response:%s", self.rid, 'ner response: ' + json.dumps(ner_response, ensure_ascii=False))
                    return result, status_code
            else:
                self.logs.info("Rid:%s; Response:%s", self.rid, 'intent response: ' + json.dumps(intent_response, ensure_ascii=False))
                response_list.append(intent_response)
                result, status_code = self.collate_response(response_list)
        else:
            intent_request = self.create_intent_request(query, model, lang, False, clean_indicator=clean_indicator,
                                                        greetings_check=greetings_check)
            intent_response = self.call_intent(intent_request)
            intent_entity_map = self.ner_data(ongoing_intent, entities)
            ner_request = self.create_ner_request(query, lang, model, intent_entity_map)
            ner_response = self.call_ner(ner_request)
            self.logs.info("Rid:%s; Response:%s", self.rid, 'intent response: ' + json.dumps(intent_response,ensure_ascii=False))
            response_list.append(ner_response)
            response_list.append(intent_response)
            result, status_code = self.collate_response(response_list)

            self.logs.info("Rid:%s; Response:%s", self.rid, 'ner response: ' + json.dumps(ner_response, ensure_ascii=False))
            return result, status_code

        return result, status_code

    @staticmethod
    def collate_response(response_list):
        consolidated_result = {}
        code = 500
        codes = []
        for results in response_list:
            code = results.get('code')
            codes.append(code)
        for result in response_list:
            if all(i in [200] for i in codes):
                consolidated_result.update(result.get('response'))
                code = 200
            else:
                consolidated_result.update(result.get('response'))
                code = 500

        return consolidated_result, code

    def get_special_intent(self, special_intent, ongoing_intent, entities,
                           query, model, lang, clean_indicator, greetings_check):
        """
        method to get special intent from the intent engine if special intent is not null
        :param special_intent:
        :param ongoing_intent:
        :param entities:
        :param query:
        :param model:
        :param lang:
        :param clean_indicator:
        :param greetings_check:
        :return: text label marked as special intent ongoing intent marked as textlabel and entity stack as is in a result
                along with status code
        """
        intent_request = self.create_intent_request(query=query, model=special_intent,
                                                    lang=lang, greetings_check=greetings_check,
                                                    special_intent_flag=True, clean_indicator=clean_indicator)
        intent_response = self.call_intent(intent_request)
        if intent_response.get("code") == 200:
            self.logs.info("Rid:%s; Response:%s", self.rid, 'intent response: ' + json.dumps(intent_response, ensure_ascii=False))
            result = {}
            special_intent_probability = intent_response.get("response").get("labelprobability")
            special_intent_value = intent_response.get("response").get("textLabel")
            intent_response["response"]["model"] = model
            intent_response["response"]["textLabel"] = ongoing_intent
            result.update(intent_response.get("response"))
            result.update({"entities": entities})
            # Incase you want to remove the keys just pop them out of dictionary as shown below
            # result.pop("textLabel")
            # result.pop("labelprobability")
            # Incase you want to keep the keys and set them to none
            result["textLabel"] = None
            result["labelprobability"] = None
            result["specialIntentProbability"] = special_intent_probability
            special_intent_key = "specialIntent"
            result.update({special_intent_key: special_intent_value})
            if special_intent_key == self.config.get("intent").get("special_intent_value"):
                additional_intent_request = self.create_intent_request(query=query, model=model,
                                                            lang=lang, special_intent_flag=False,
                                                            clean_indicator=clean_indicator, greetings_check=greetings_check)
                additional_intent_response = self.call_intent(additional_intent_request)
                result["textLabel"] = additional_intent_response.get("response").get("textLabel")
                result["labelprobability"] = additional_intent_response.get("response").get("labelprobability")
                result["specialIntentProbability"] = special_intent_probability

            self.logs.info("Rid:%s; Response:%s", self.rid, 'special intent response' + json.dumps(result, ensure_ascii=False))
            return result, 200
        else:
            response_list = []
            self.logs.info("Rid:%s; Response:%s", self.rid,
                           'intent response: ' + json.dumps(intent_response, ensure_ascii=False))
            response_list.append(intent_response)
            result, status_code = self.collate_response(response_list)
            self.logs.info("Rid:%s; Response:%s", self.rid, 'special intent response' + json.dumps(result, ensure_ascii=False))
            return result, status_code

    def make_api_calls(self, query, lang, model):
        """
        main method of prediction service which makes async predict API calls to intent and NER predict services
        :param query:
        :param lang:
        :param model:
        :return: NA
        """
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        future = asyncio.ensure_future(self.get_data_asynchronous(query, lang, model))
        loop.run_until_complete(future)

    def setup_mongo_operations(self, model, lang, collection_name):
        """

        :return:
        """
        document_name = model + '_' + lang
        intent_entity_map_val = self.mongo_manager.get_document_from_collection(document_name=document_name,
                                                                                collection_name=collection_name)
        if intent_entity_map_val is not None:
            return intent_entity_map_val
        else:
            return None


if __name__ == '__main__':
    predict = Prediction(config=CONFIG)
    q = "play movie song"
    lang = "en"
    model = "luka_chuppi"
    predict.make_api_calls(q, lang, model)
    predict.collate_response()
