from redis.sentinel import Sentinel


class RedisInit:
    def __init__(self, config):
        """
        Initialize a redis sentinal master node along with slave nodes if any
        :param config:
        """
        self.config = config

    def redis_connection(self):
        """
        read config and based on the parameters configure redis master
        :return: redis master object
        """
        redis_v = {}
        for sentinels in self.config.get('sentinel_info'):
            redis_v[sentinels.get('sentinel_host')] = sentinels.get('sentinel_port')
        redis_list = list(redis_v.items())
        sentinel = Sentinel(redis_list, socket_timeout=self.config.get('socket_timeout'), password=self.config.get('password', None))
        master = sentinel.master_for(self.config.get('master_name'), socket_timeout=self.config.get('master_socket_timeout'), password=self.config.get('password', None))
        print(master)
        return master


class RedisManager:

    def redis_insert(self, key, dict_to_redis, master):
        """
        set key value in redis DB
        :param key:
        :param dict_to_redis:
        :param master:
        :return: NA
        """
        dict_to_redis = str(dict_to_redis)
        master.set(key, dict_to_redis)

    def redis_delete(self, model, lang, master):
        """
        deletes key from redis DB
        :param model:
        :param lang:
        :param master:
        :return: NA
        """
        master.delete(model + '_' + lang)

    def redis_get(self, key, master):
        """
        given a key fetch it's value from redis DB
        :param key:
        :param master:
        :return: data for the key
        """
        if master.keys(key):
            data = master.get(key)
            try:
                data = eval(data)
            except:
                data = data.decode("utf-8")
            return data
        else:
            data = "key not found"
            return data
