import json
import asyncio
from concurrent.futures import ThreadPoolExecutor
import requests
import pandas as pd
import os
import os.path
from nfs_operations import ZipOperations
from nfs_operations import NfsStorage
from nfs_operations import TextOperations
from datetime import datetime
import pytz
import ast

DIR_PATH = os.path.dirname(os.path.realpath(__file__))
intent_entity_map_file = os.path.join(DIR_PATH, 'intent_entity_map', 'intent_entity_map.json')


class Training:

    def __init__(self, config, model_folder, logs, rid, redis_master, redis_manager):
        """
        Initializes the train object for a train request
        :param config:
        :param model_folder:
        :param logs:
        :param rid:
        """
        self.zip_file_name = ''
        self.redis_manager = redis_manager
        self.redis_master = redis_master
        self.config = config
        self.model_folder = model_folder
        self.final_response = []
        self.logs = logs
        self.rid = rid
        self.intent_entity_map_path = intent_entity_map_file

    def db_operations(self, model, lang):
        """

        :return:
        """
        property_file = os.path.join(self.model_folder, "entity_property_file.json")
        property_file_data = open(property_file, 'rb')
        db_url = self.config.get("db_operations").get("url")
        db_auth = self.config.get("db_operations").get("authorization")
        entity_file = {'property_file': property_file_data}
        db_request = {
            "url": db_url,
            "auth": db_auth,
            "param":  {"model": model, "lang": lang},
            "files": entity_file
        }
        with requests.Session() as session:
            response = self.fetch_response(session, db_request.get("url"), db_request.get("auth"),
                                           db_request.get("param"), db_request.get("files"))
            if response.get("code") == 200:
                return True
            else:
                return False

    def get_train_file(self, model, lang):
        training_file_name = "training_" + model + "." + lang + ".csv"
        training_data_path = os.path.join(self.model_folder, training_file_name)
        return training_data_path

    def validate_train_file(self, train_file, model_folder, model, lang):
        """
         check number of columns and return files
        number of columns will decide if ner needs to be trained or not
        :param train_file:
        :param model_folder:
        :param model:
        :param lang:
        :return:
        """
        ner_file_name = "training_ner_" + model + "." + lang + ".csv"
        intent_file_name = "training_intent_" + model + "." + lang + ".csv"
        self.ner_file_path = os.path.join(model_folder, ner_file_name)
        self.intent_file_path = os.path.join(model_folder, intent_file_name)
        training_file = pd.read_csv(train_file)
        no_of_columns = len(training_file.columns)

        if no_of_columns == 2:

            training_file.columns = ['label', 'expression']
            training_file.to_csv(self.intent_file_path, index=False)

        elif no_of_columns == 3:

            training_file.columns = ['label', 'expression', 'entities']
            # Impute all null/nan/blank values of entities column with: {'entities': []}
            training_file["entities"].fillna("{'entities': []}", inplace=True)
            ner_file = training_file[['expression', 'entities']].copy()
            ner_file['entities'] = ner_file['entities'].apply(self.convert_for_spacy)
            intent_file = training_file[['label', 'expression']].copy()
            intent_file.to_csv(self.intent_file_path, header=False, index=False)
            ner_file.to_csv(self.ner_file_path, header=False, index=False)

        return no_of_columns

    def convert_for_spacy(self, list_to_convert):
        """

        :param list_to_convert:
        :return:
        """
        try:
            list_to_convert = json.loads(list_to_convert)
        except Exception as e:
            list_to_convert = ast.literal_eval(list_to_convert)

        data = list_to_convert.get("entities")
        return {"entities": [self.convert_dict(val) for val in data]}

    @staticmethod
    def convert_dict(dict_to_convert):
        """

        :param dict_to_convert:
        :return:
        """
        return (dict_to_convert.get("startIndex"), dict_to_convert.get("endIndex"), dict_to_convert.get("name")) # noqa

    def create_request(self, lang, algo, model, stopwords_remove,
                       syn_form, clean_indicator, callback, fallback, column_count):
        """
        makes a list of requests for training intent and NER
        :param lang:
        :param algo:
        :param model:
        :param stopwords_remove:
        :param syn_form:
        :param clean_indicator:
        :param callback:
        :param fallback:
        :param column_count:
        :return: a list of intent and ner train requests
        """
        ner_url = self.config.get("ner").get("training")
        ner_auth = self.config.get("ner").get("authorization")
        intent_url = self.config.get("intent").get("training")
        intent_auth = self.config.get("intent").get("authorization")
        train_requests = []
        intent_file_data = open(self.intent_file_path, 'rb')
        ner_file_data = open(self.ner_file_path, 'rb')
        intent_file = {'file_upload': intent_file_data}
        ner_files = {"file": ner_file_data}
        intent_request = {
                            "url": intent_url,
                            "auth": intent_auth,
                            "param": {"model": model, "lang": lang,
                                      "algo": algo,
                                      "syn_form": syn_form,
                                      "stopwords_remove": stopwords_remove,
                                      "clean_indicator": clean_indicator,
                                      "callback": "",
                                      "fallback": ""
                                      },
                            "files": intent_file
                            }
        self.logs.info("Rid:%s; intent request param:%s", self.rid, json.dumps(intent_request.get("param")))
        self.logs.info("Rid:%s; intent request url:%s", self.rid, json.dumps(intent_request.get("url")))
        train_requests.append(intent_request)

        if column_count == 2:

            return train_requests

        elif column_count == 3:

            ner_request = {
                            "url": ner_url,
                            "auth": ner_auth,
                            "param": {"model": model,
                                      "lang": lang
                                      },
                            "files": ner_files
                            }

            train_requests.append(ner_request)
            self.logs.info("Rid:%s; ner request request param:%s", self.rid, json.dumps(ner_request.get("param")))
            self.logs.info("Rid:%s; ner request url:%s", self.rid, json.dumps(ner_request.get("url")))
            return train_requests

    async def get_data_asynchronous(self, lang, algo, model,
                                    stopwords_remove, syn_form, clean_indicator,
                                    callback, fallback, column_count):
        """
        calls intent and ner train api in async
        :param lang:
        :param algo:
        :param model:
        :param stopwords_remove:
        :param syn_form:
        :param clean_indicator:
        :param callback:
        :param fallback:
        :param column_count:
        :return: a list of consolidated responses of train APIs of intent and NER
        """
        train_apis = self.create_request(lang, algo, model,
                                         stopwords_remove, syn_form, clean_indicator,
                                         callback, fallback, column_count)
        with ThreadPoolExecutor(max_workers=10) as executor:
            with requests.Session() as session:
                # Set any session parameters here before calling `fetch`
                loop = asyncio.get_event_loop()
                tasks = [
                    loop.run_in_executor(
                        executor,
                        self.fetch_response,
                        *(session, url.get("url"), url.get("auth"), url.get("param"), url.get("files"))
                        # Allows us to pass in multiple arguments to `fetch`
                    )
                    for url in train_apis
                ]
                for response in await asyncio.gather(*tasks):
                    self.final_response.append(response)
        self.logs.info("Rid:%s; final_response array in async call:%s", self.rid, str(self.final_response))

    def get_data_synchronous(self, lang, algo, model,
                                    stopwords_remove, syn_form, clean_indicator,
                                    callback, fallback, column_count):
        """
        calls intent and ner train api in sync
        :param lang:
        :param algo:
        :param model:
        :param stopwords_remove:
        :param syn_form:
        :param clean_indicator:
        :param callback:
        :param fallback:
        :param column_count:
        :return: a list of consolidated responses of train APIs of intent and NER
        """

        train_apis = self.create_request(lang, algo, model,
                                         stopwords_remove, syn_form, clean_indicator,
                                         callback, fallback, column_count)
        with requests.Session() as session:
            self.final_response = [self.fetch_response(session, url.get("url"), url.get("auth"), url.get("param"), url.get("files")) for url in train_apis]
            self.logs.info("Rid:%s; final_response array in sync call:%s", self.rid, str(self.final_response))

    def fetch_response(self, session, url, auth, param, files):
        """
        request making method, given a set of parameters makes a http request and gets the response
        :param session:
        :param url:
        :param auth:
        :param param:
        :param files:
        :return: returns API response
        """
        try:
            with session.post(url, headers={'Authorization': auth}, params=param, files=files) as response:

                if response.status_code == 200:
                    data = json.loads(response.text)
                else:
                    response.text = response.text.replace('\n', '')
                    data = {"Error": response.text}
                return {'code': response.status_code, 'response': data}
        except Exception as e:
            self.logs.info("Rid:%s; internal server error:%s", self.rid,  str(e))
            return {'code': '500', 'response': 'internal server error : ' + str(e)}

    def make_api_calls(self, lang, algo, model, stopwords_remove, syn_form, clean_indicator, callback, fallback):
        """
         main method of prediction service which makes async Train API calls to intent and NER predict services
        :param lang:
        :param algo:
        :param model:
        :param stopwords_remove:
        :param syn_form:
        :param clean_indicator:
        :param callback:
        :param fallback:
        :return: NA
        """
        # self.update_intent_entity_map(model_folder=self.model_folder, model=model, lang=lang)
        db_status = self.db_operations(model=model, lang=lang)
        if db_status:
            train_file = self.get_train_file(model=model, lang=lang)
            column_count = self.validate_train_file(train_file, self.model_folder, model, lang)
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            future = asyncio.ensure_future(self.get_data_asynchronous(lang, algo, model, stopwords_remove,
                                                                     syn_form, clean_indicator, callback,
                                                                     fallback, column_count))
            loop.run_until_complete(future)
        else:
            self.logs.info("Rid:%s; internal server error:%s", self.rid, "db operations failed please try again later")
            raise ValueError("db operations failed please try again later")

    def consolidated_response(self):
        """
        collates the responses from a list and sets status code
        :return: consolidated json along with final request code
        """
        consolidated_result = {}
        code = 500
        codes = []
        for results in self.final_response:
            code = results.get('code')
            codes.append(code)
        for response in self.final_response:
            if all(i in [200] for i in codes):
                consolidated_result.update(response.get('response'))
                code = 200
            else:
                consolidated_result.update(response.get('response'))
                code = 500
        self.logs.info("Rid:%s; consolidated response:%s", self.rid, json.dumps(consolidated_result))
        return consolidated_result, code
