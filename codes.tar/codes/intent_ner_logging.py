import os
import time
import logging
from logging.handlers import RotatingFileHandler


def logging_function(name_of_file, name_of_log_file, level=logging.INFO):
    # This function will take input type of logging should be used and returns the logging
    main_path = os.path.join(os.getcwd(), "intent_ner_logs")
    folder_name = str(time.strftime("%d%m%y"))
    os.makedirs(os.path.join(main_path, folder_name), exist_ok=True)
    path = os.path.join(main_path, folder_name, name_of_file)
    os.makedirs(path, exist_ok=True)
    logger = logging.getLogger(folder_name + name_of_log_file)
    logger.propagate = False
    if not logger.handlers:
        formatter = logging.Formatter('%(asctime)s %(message)s', datefmt='%d-%m-%Y %H:%M:%s')
        handler = logging.handlers.RotatingFileHandler(path + "/" + name_of_log_file, maxBytes=100000000,
                                                       backupCount=10)
        handler.setFormatter(formatter)
        logger.setLevel(level)
        logger.addHandler(handler)

    return logger


