#!/bin/bash
nohup python -u service.py &
celery worker -A service.celery --loglevel=info -f /app/intent_ner_logs/celery.log
