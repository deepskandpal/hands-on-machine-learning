#!/usr/bin/env bash

tar --exclude=data --exclude=.git --exclude=*.tar.gz --exclude=redis-stable --exclude=*.txt   -cvf app.tar.gz ./

docker login -u jiotechspecial -p Lrq6+ETXvZDTNv0mIevWJMR19NgGVdH4 jiotechspecial.azurecr.io

docker build -t intent_ner -f Dockerfile .

docker tag intent_ner:latest jiotechspecial.azurecr.io/jioml/intent-ner:switch_intent

docker push jiotechspecial.azurecr.io/jioml/intent-ner:switch_intent

docker tag jiotechspecial.azurecr.io/jioml/intent-ner:switch_intent 10.141.54.104:5204/jioml-eva/ml-wrapper/intent_ner:ph3_vswitch_intent

docker push 10.141.54.104:5204/jioml-eva/ml-wrapper/intent_ner:ph3_vswitch_intent