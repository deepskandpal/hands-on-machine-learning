import requests
import json
import os


class Cancel:

    def __init__(self, config, cancel, logs, rid, model_info=None, master=None):
        self.logs = logs
        self.rid = rid
        self.config = config
        self.response = cancel
        self.model = model_info
        self.master = master

    def fetch_response(self, session, url, auth):
        """
        request making method, given a set of parameters makes a http request and gets the response
        :param session:
        :param url:
        :param auth:
        :return: returns API response
        """
        try:
            with session.delete(url, headers={'Authorization': auth}) as response:

                if response.status_code == 200:
                    try:
                        data = json.loads(response.text)
                    except:
                        data = response.text
                else:
                    data = {"Error": response.text}
                return {'code': response.status_code, 'response': data}
        except Exception as e:
            self.logs.info("Rid:%s; internal server error:%s", self.rid, str(e))
            return {'code': '500', 'response': 'internal server error : ' + str(e)}

    def create_intent_request(self, response):
        intent_url = self.config.get("intent").get("cancel")
        intent_id = response.get('task_id')
        intent_auth = self.config.get("intent").get("authorization")
        model = self.model.get('model')
        lang = self.model.get('lang')
        intent_url = os.path.join(str(intent_url), model, lang, intent_id)
        intent_request = {
            "url": intent_url,
            "auth": intent_auth,
        }
        self.logs.info("Rid:%s; intent request:%s", self.rid, json.dumps(intent_request))
        return intent_request

    def call_intent_request(self, intent_request):
        with requests.Session() as session:
            response = self.fetch_response(session, intent_request.get("url"), intent_request.get("auth"))
            return response

    def create_ner_request(self, response):
        ner = response.get('ner')
        self.logs.info("Rid:%s; ner:%s", self.rid, json.dumps(ner))
        if ner is not None:
            ner_id = ner.get("task_id")
            ner_auth = self.config.get("ner").get("authorization")
            self.logs.info("Rid:%s; ner auth :%s", self.rid, str(ner_auth))
            ner_url = self.config.get("ner").get("cancel")
            self.logs.info("Rid:%s; ner url :%s", self.rid, str(ner_url))
            model = self.model.get('model')
            lang = self.model.get('lang')
            ner_url = os.path.join(str(ner_url), model, lang, ner_id)
            ner_request = {
                "url": ner_url,
                "auth": ner_auth,
            }
            self.logs.info("Rid:%s; ner request:%s", self.rid, json.dumps(ner_request))
            return ner_request

    def call_ner_request(self, ner_request):
        with requests.Session() as session:
            response = self.fetch_response(session, ner_request.get("url"), ner_request.get("auth"))
            return response

    def delete_from_redis(self, master):
        model = self.model.get('model')
        lang = self.model.get('lang')
        master.delete('ml_' + model + '_' + lang)
        self.logs.info("Rid:%s; key deleted from redis API:%s", self.rid, str('ml_' + model + '_' + lang))

    def make_api_calls(self):
        intent_request = self.create_intent_request(self.response)
        intent_response = self.call_intent_request(intent_request)
        self.logs.info("Rid:%s; intent response:%s", self.rid, json.dumps(intent_response))
        intent_code = intent_response.get("code")
        if intent_code == 200 or intent_code == 400:
            ner_request = self.create_ner_request(self.response)
            ner_response = self.call_ner_request(ner_request)
            self.logs.info("Rid:%s; ner response:%s", self.rid, json.dumps(ner_response))
            response_to_match_ner = self.match_response(self.response, "ner")
            ner = ner_response.get("response").get("ner")
            ner_code = ner.get("status")
            if response_to_match_ner == ner:
                self.delete_from_redis(self.master)
                response = {"code": 200, "response": "training cancelled successfully "}
                return response, 200
            elif ner_code == 400:
                self.delete_from_redis(self.master)
                return {"code": 200, "response": "training cancelled successfully "}, 200
            else:
                self.delete_from_redis(self.master)
                self.logs.info("Rid:%s; ner response:%s", self.rid, json.dumps(ner_response))
                response = {"code": 500, "response": "error while canceling"}
                return response, 500
        else:
            self.delete_from_redis(self.master)
            response = {"code": 500, "response": "error while canceling"}
            self.logs.info("Rid:%s; error while canceling intent:%s", self.rid, json.dumps(intent_response))
            return response, 500

    @staticmethod
    def match_response(response, flag):
        """
        successful intent response : {'Revoke_status': '5d6b915b-d978-4836-b6f8-86120d781703 revoked.'}
        successful ner response : {'revoked_id': task_id}
        :param response:
        :param flag:
        :return:
        """
        if flag == "intent":
            intent_id = response.get('task_id')
            response_to_check = {'Revoke_status': str(intent_id) + ' revoked.'}
            return str(response_to_check)
        else:
            ner_id = response.get("ner").get("task_id")
            response_to_check = {"revoked_id": ner_id}
            return response_to_check

    def cancel_failed_training(self, intent_state, ner_state):
        """
        additional cancellation function for cancelling a training
        :return: NA
        """
        if intent_state == 'FAILURE' or intent_state is None:
            self.logs.info("Rid:%s; entered ner cancellation check", self.rid)
            ner_request = self.create_ner_request(self.response)
            ner_response = self.call_ner_request(ner_request)
            response_to_match_ner = self.match_response(self.response, "ner")
            ner = ner_response.get("response").get("ner")
            if response_to_match_ner == ner:
                self.delete_from_redis(self.master)
                self.logs.info("Rid:%s; ner cancelled successfully:%s", self.rid, json.dumps(ner_response))
            else:
                self.logs.info("Rid:%s; error in cancelling ner:%s", self.rid, json.dumps(ner_response))

        if ner_state == 'FAILURE' or ner_state is None:
            self.logs.info("Rid:%s; entered intent cancellation check", self.rid)
            intent_request = self.create_intent_request(self.response)
            intent_response = self.call_intent_request(intent_request)
            response_to_match = self.match_response(self.response, "intent")
            intent = intent_response.get("response")
            if response_to_match == intent:
                self.delete_from_redis(self.master)
                self.logs.info("Rid:%s; Intent cancelled successfully:%s", self.rid, json.dumps(intent_response))
            else:
                self.logs.info("Rid:%s; error in cancelling intent:%s", self.rid, json.dumps(intent_response))
