import os
import requests


DIR_PATH = os.path.dirname(os.path.realpath(__file__))


class Utils:

    def __init__(self, redis_manager, redis_master, config):
        self.redis_manager = redis_manager
        self.redis_master = redis_master
        self.config = config

    def is_lang_appropriate(self, lang):
        if lang in self.config.get("languages"):
            return True
        else:
            return False

    @staticmethod
    def save_train_file(request, model, lang, model_folder):
        file_present = False
        training_file_name = "training_" + model + "." + lang + ".csv"
        training_data_path = os.path.join(DIR_PATH, model_folder, training_file_name)
        file = request.files.get('training_file')
        if file is not None:
            if request.files['training_file'].filename == '' and training_data_path not in os.listdir(DIR_PATH):
                file_present = False
                file_missing = 'training_file'
                return file_present, file_missing
            else:
                file_present = True
                training_file = request.files['training_file']
                training_file.save(training_data_path)
        else:
            file_present = False
            file_missing = 'training_file'
            return file_present, file_missing

        entity_property_file = request.files.get('entity_property_file')
        property_file_path = os.path.join(DIR_PATH, model_folder)
        if entity_property_file is not None:
            if request.files['entity_property_file'].filename == '' and property_file_path not in os.listdir(DIR_PATH):
                file_present = False
                file_missing = 'entity_property_file'
                return file_present, file_missing
            else:
                file_present = True
                property_file = request.files['entity_property_file']
                property_file.save(os.path.join(DIR_PATH, model_folder, 'entity_property_file.json'))
        else:
            file_present = False
            file_missing = 'entity_property_file'
            return file_present, file_missing

        return file_present, ''

    def callback_url(self, callback, headers, model, lang):
        if callback == '':
            return 'Success'
        else:
            url = callback
            try:
                r = requests.get(url, headers=headers)
                if not r.ok:
                    self.redis_manager.redis_delete(model, lang, self.redis_master)
                    return 'Failed'
                return 'Success'
            except Exception as e:
                return 'Failed'

    def fallback_url(self, fallback, headers, model, lang):
        if fallback == '':
            return 'Success'
        else:
            url = fallback
            try:
                r = requests.get(url, headers=headers)
                if not r.ok:
                    self.redis_manager.redis_delete(model, lang, self.redis_master)
                    return 'Failed'
                return 'Success'
            except Exception as e:
                return 'Failed'

    @staticmethod
    def convert_lang(lang):
        if lang == "dev":
            lang = "hi"
            return lang
        else:
            return lang

    @staticmethod
    def get_train_params(args):
        lang = args.get('lang')
        model = args.get('model')
        algo = args.get('algo')
        callback = args.get('callback')
        fallback = args.get('fallback')
        stopwords_remove = args.get('stopwords_remove')
        syn_form = args.get('syn_form')
        clean_indicator = args.get('clean_indicator')
        return lang, model, algo, callback, fallback, stopwords_remove, syn_form, clean_indicator

    @staticmethod
    def get_predict_params(args):
        lang = args.get('lang')
        model = args.get('model')
        query = args.get('q')
        algo = args.get('algo')
        clean_indicator = args.get('clean_indicator')
        greetings_check = args.get('clean_indicator')
        return lang, model, query, algo, clean_indicator, greetings_check

    @staticmethod
    def get_status_params(args):
        task_id = args.get('task_id')
        return task_id

    def get_params(self, args, flag):
        if flag == 'predict':
            lang, model, query, algo, clean_indicator, greetings_check = self.get_predict_params(args)
            return lang, model, query, algo, clean_indicator, greetings_check
        elif flag == 'train':
            lang, model, algo, callback, fallback, stopword_remove, syn_form, clean_indicator = self.get_train_params(args)
            return lang, model, algo, callback, fallback, stopword_remove, syn_form, clean_indicator

    @staticmethod
    def create_train_param_dict(lang, model, algo, callback, fallback, stopwords_remove, syn_form, clean_indicator):
        param_dict = {
            "lang": lang,
            "model": model,
            "algo": algo,
            "callback": callback,
            "fallback": fallback,
            "stopwords_remove": stopwords_remove,
            "syn_form": syn_form,
            "clean_indicator": clean_indicator
        }
        return param_dict

    @staticmethod
    def create_predict_param_dict(lang, model, query, algo, clean_indicator, greetings_check):
        param_dict = {
                "lang": lang,
                "model": model,
                "query": query,
                "algo": algo,
                "clean_indicator": clean_indicator,
                "greetings_check": greetings_check
        }
        return param_dict

    @staticmethod
    def create_data_folder():
        data_path = os.path.join(DIR_PATH, 'data')
        if not os.path.exists(data_path):
            os.mkdir(data_path)
        else:
            print("data folder already exists")
        return data_path

    @staticmethod
    def create_folder(model_folder_name, model_name):
        if not os.path.exists(model_folder_name):
            os.mkdir(model_folder_name)
            print("Directory ", model_folder_name, " Created ")
        else:
            print("Directory ", model_folder_name, " already exists")

        model_path = os.path.join(model_folder_name, model_name)

        if not os.path.exists(model_path):
            os.mkdir(model_path)
        else:
            print("Directory ", model_path, " already exists")
        return model_path
