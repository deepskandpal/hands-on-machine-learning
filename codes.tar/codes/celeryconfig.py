from __future__ import absolute_import, print_function, unicode_literals

CELERY_IMPORTS = ("service",)

BROKER_URL = 'redis-sentinel://redis-sentinel:26379/4'
BROKER_TRANSPORT_OPTIONS = {
        'sentinels': [('10.2.29.4', 26379)],
    'service_name': 'mymaster',
    'socket_timeout': 1,
}

CELERY_RESULT_BACKEND = 'redis-sentinel://redis-sentinel:26379/5'
CELERY_RESULT_BACKEND_TRANSPORT_OPTIONS = BROKER_TRANSPORT_OPTIONS
