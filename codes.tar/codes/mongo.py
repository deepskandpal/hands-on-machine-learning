import os
from pymongo import MongoClient


class MongoManager:
    """

    """

    def __init__(self, config):
        self.mongo_config = config
        self.connection = MongoClient(self.mongo_config.get('ip', 'localhost'),
                             self.mongo_config.get('port', '27017'),
                             username=self.mongo_config.get('username'),
                             password=self.mongo_config.get('password'),
                             connect=self.mongo_config.get('connect', False))
        self.data_base = self.connection[self.mongo_config.get('db_name')]

    def check_collection(self, collection_name):
        """

        :param collection_name:
        :return:
        """
        if collection_name not in self.data_base.list_collection_names():
            collection = self.data_base[collection_name]
            return collection
        return self.data_base[collection_name]

    def check_db(self):
        """

        :return:
        """
        db_names = self.connection.list_database_names()
        db_name = self.mongo_config.get("db_name")
        if db_name not in db_names:
            data_base = self.connection[db_name]
            return None
        else:
            data_base = self.connection[db_name]
        return data_base

    def check_document_in_collection(self, document, collection_name):
        """

        :param document:
        :param collection_name:
        :return:
        """
        document_name = document
        collection = self.check_collection(collection_name)
        if self.data_base is not None:
            if self.data_base[collection_name].count() != 0:
                if collection.find({"model": document_name}).count() > 0:
                    return True
            else:
                return False
        else:
            print("db not found")
            return False

    def get_document_from_collection(self, document_name, collection_name):
        """

        :param document_name:
        :param collection_name:
        :return:
        """
        try:
            collection_db = self.check_collection(collection_name=collection_name)
            is_document_present = self.check_document_in_collection(document_name, collection_name)
            if not is_document_present:
                print("model document not present")
                return None
            else:
                intent_entity_map = collection_db.find_one({'model': document_name})
                return intent_entity_map

        except Exception as e:
            print(e)
            return None
