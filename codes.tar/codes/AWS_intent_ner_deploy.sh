#!/usr/bin/env bash

tar --exclude=data --exclude=.git --exclude=*.tar.gz --exclude=redis-stable --exclude=*.txt   -cvf app.tar.gz ./

$(aws ecr get-login --no-include-email)

docker build -t intent_ner -f Dockerfile .

docker tag intent_ner:latest 460015929520.dkr.ecr.ap-south-1.amazonaws.com/hellojioml:ongoing_intent_v4

docker push 460015929520.dkr.ecr.ap-south-1.amazonaws.com/hellojioml:ongoing_intent_v4

docker tag 460015929520.dkr.ecr.ap-south-1.amazonaws.com/hellojioml:ongoing_intent_v4 10.141.54.104:5204/hellojioml/intent_ner:ongoing_intent_v4

docker push 10.141.54.104:5204/hellojioml/intent_ner:ongoing_intent_v4