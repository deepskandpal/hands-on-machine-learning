"""
NFS operations for intent-ner
The purpose of NFS operations is to provide the functionality of sharing files between multiple instance of this service
The idea is simple
Whenever the shared file is uploaded it is saved and zipped along with a time stamp.
the same time stamp is written in the Redis DB.
The zipped file is then pushed to the NFS storage.
During prediction there will be a version file which will be on the local storage of the instance.
The Prediction service will check the redis for the version value (Time Stamp).


"""

import zipfile
import os
import shutil


class ZipOperations:

    def __init__(self):
        pass

    @staticmethod
    def check_zip(zip_filename):
        """
        check if the file is zip
        :param zip_filename:
        :return:
        """

        if zip_filename.endswith(".zip"):
            return True

        return False

    @staticmethod
    def unzip_folder(zip_filename, unzip_folder):
        """
        unzip file
        :param zip_filename:
        :param unzip_folder:
        :return:
        """

        try:
            zip_obj = zipfile.ZipFile(zip_filename)
            zip_obj.extractall(unzip_folder)
            zip_obj.close()
        except Exception as e:
            return False

        return True

    @staticmethod
    def remove_zip(zip_filename):
        """remove zip file"""

        try:
            os.remove(zip_filename)

        except Exception as e:
            return False

        return True

    @staticmethod
    def zip_folder(unzip_folder, zip_filename):
        """zip a folder"""

        rootdir = os.path.basename(unzip_folder)

        with zipfile.ZipFile(zip_filename, 'w') as zip:
            for root, directories, files in os.walk(unzip_folder):
                for filename in files:
                    file_path = os.path.join(root, filename)
                    parentpath = os.path.relpath(file_path, unzip_folder)
                    arcname = os.path.join(rootdir, parentpath)
                    zip.write(file_path, arcname)
            zip.close()

        return True


class NfsStorage:

    def __init__(self):
        pass

    def upload_folder(self, source_folder, dist_folder):
        """
        Upload a directory to NFS
        :param source_folder:
        :param dist_folder:
        :return:
        """
        try:
            # delete existing data before upload
            if dist_folder:
                self.delete_folder(dist_folder)

            shutil.copytree(source_folder, dist_folder)

            return True
        except Exception as e:

            return False

    @staticmethod
    def upload_file(source_file, dist_file):
        """
        Upload a file to NFS
        :param source_file:
        :param dist_file:
        :return:
        """
        try:

            shutil.copy(source_file, dist_file)

            return True
        except Exception as e:
            print(e)

            return False

    def download_folder(self, source_folder, dist_folder):
        """
        Download from NFS folder
        :param source_folder:
        :param dist_folder:
        :return:
        """
        try:
            # delete existing data before download
            if os.path.exists(dist_folder):
                self.delete_folder(dist_folder)

            shutil.copytree(source_folder, dist_folder)

            return True
        except Exception as e:

            return False

    @staticmethod
    def download_file(source_file, dist_file):
        """
        Download a file from NFS
        :param source_file:
        :param dist_file:
        :return:
        """
        try:

            shutil.copy(source_file, dist_file)

            return True
        except Exception as e:

            return False

    @staticmethod
    def delete_folder(folder_path):
        """
        Delete Folder
        :param folder_path:
        :return:
        """
        try:
            shutil.rmtree(folder_path)

            return True
        except Exception as e:

            return False


class TextOperations:

    def __init__(self):
        pass

    @staticmethod
    def read_text(text_filename):
        """
        read text file
        :param text_filename:
        :return:
        """

        text_file = open(text_filename, "r")
        text_val = text_file.readline()
        text_file.close()

        return text_val

    @staticmethod
    def write_text(text_filename, value):
        """
        write text file
        :param text_filename:
        :param value:
        :return:
        """

        text_file = open(text_filename, "w")
        text_file.write(value)
        text_file.close()

        return True
