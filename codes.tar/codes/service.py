import json
from flask import Flask, jsonify, request
from functools import wraps
from prediction import Prediction
from training import Training
from status import Status
from redis_manager import *
from util import *
from uuid import uuid4
from intent_ner_logging import logging_function
from cancel import Cancel
from polling2 import TimeoutException, poll
from celery import Celery
from celery_redis_sentinel import register
from celery_redis_sentinel.task import EnsuredRedisTask
from mongo import MongoManager

# Service initilization

app = Flask(__name__)


DIR_PATH = os.path.dirname(os.path.realpath(__file__))

# Configs

intent_entity_map_file = os.path.join(DIR_PATH, 'intent_entity_map', 'intent_entity_map.json')
CONFIG_FILE = os.path.join(DIR_PATH, 'configs', 'config.json')
VERSION_FILE = os.path.join(DIR_PATH, 'configs', 'version.json')
MONGO_CONFIG_FILE = os.path.join(DIR_PATH, 'configs', 'mongo.json')

# Ancillary objects
CONFIG = json.load(open(CONFIG_FILE))
MONGO_CONFIG = json.load(open(MONGO_CONFIG_FILE))
redis_master = RedisInit(config=CONFIG.get("redis"))
manage_redis = RedisManager()
master = redis_master.redis_connection()
mongo_manager = MongoManager(MONGO_CONFIG)
utils = Utils(redis_manager=manage_redis, redis_master=master, config=CONFIG)
encoding = 'utf-8'

# Celery Details
register()
celery = Celery('service')
celery.config_from_object('celeryconfig')


def valid_credentials(username, password):
    return username == CONFIG.get('user') and password == CONFIG.get('pass')


def authenticate(f):
    """
    authentication wrapper
    :param f:
    :return: NA
    """
    @wraps(f)
    def wrapper(*args, **kwargs):
        auth = request.authorization
        if not auth or not valid_credentials(auth.username, auth.password):
            return jsonify({'message': 'JIOML rejects your request - Error 403'})
        return f(*args, **kwargs)

    return wrapper


@app.route("/api/v3/prediction", methods=['GET', 'POST'])
@authenticate
def prediction():
    """
    Prediction route for Intent NER API
    :return: consolidated results from NER and intent for a model and lang
    """
    log_predict = logging_function("prediction", "predict.log")
    log_predict_debug = logging_function("prediction", "predict_debug.log")

    Rid = str(uuid4())
    try:
        predict = Prediction(redis_master=master, redis_manager=manage_redis, config=CONFIG, logs=log_predict_debug,
                             rid=Rid, version_file=VERSION_FILE, mongo_manager=mongo_manager)
        lang, model, query, algo, clean_indicator, greetings_check = utils.get_params(request.args, 'predict')
        lang = utils.convert_lang(lang)
        param_dict = utils.create_predict_param_dict(lang, model, query, algo, clean_indicator, greetings_check)
        log_predict.info("Rid:%s; Request:%s", Rid, json.dumps(param_dict, ensure_ascii=False))
        if all(v is not None for v in
               [lang, model, query, algo, clean_indicator, greetings_check]):
            collection_name = MONGO_CONFIG.get("db_collection")
            intent_entity_map = predict.setup_mongo_operations(model=model, lang=lang, collection_name=collection_name)
            if intent_entity_map is None:
                message = "model not found please try again later"
                e = {"error": message}
                log_predict.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))
                return jsonify(e), 400
            else:
                if request.data:

                        special_intent_dict = {
                                        "specialIntent": None
                                        }

                        request_data = json.loads(request.data)
                        log_predict_debug.info("Rid:%s; form body:%s", Rid, json.dumps(request_data, ensure_ascii=False).encode(encoding))
                        ongoing_intent = request_data.get("ongoing_intent")
                        special_intent = request_data.get("specialIntent")
                        entities = request_data.get("entities")
                        if special_intent:
                            result, status_code = predict.get_special_intent(entities=entities,
                                                                             ongoing_intent=ongoing_intent,
                                                                             special_intent=special_intent,
                                                                             lang=lang,
                                                                             model=model,
                                                                             query=query,
                                                                             clean_indicator=clean_indicator,
                                                                             greetings_check=greetings_check
                                                                             )
                            log_predict.info("Rid:%s; Response:%s", Rid, json.dumps(result, ensure_ascii=False))
                            return jsonify(result), status_code

                        if not entities:
                            response = {}
                            result, status_code = predict.get_intent_for_ner(query, lang, model,
                                                                             ongoing_intent,
                                                                             None, intent_entity_map, clean_indicator,
                                                                             greetings_check=greetings_check)
                            response.update(result)
                            response.update(special_intent_dict)
                            log_predict.info("Rid:%s; Response:%s", Rid, json.dumps(response, ensure_ascii=False))
                            return jsonify(response), status_code
                        else:
                            response = {}
                            result, status_code = predict.get_intent_for_ner(query, lang, model,
                                                                             ongoing_intent, entities,
                                                                             intent_entity_map, clean_indicator
                                                                             , greetings_check=greetings_check)
                            # predict.make_api_calls(query, lang, model)
                            # result, status_code = predict.consolidated_response()
                            response.update(result)
                            response.update(special_intent_dict)
                            log_predict.info("Rid:%s; Response:%s", Rid, json.dumps(response, ensure_ascii=False))
                            return jsonify(response), status_code
                else:
                    message = "please provide body in raw data in dictionary form "
                    e = {"error": message}
                    log_predict.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))
                    return jsonify(e), 400
        else:
            message = "please provide all parameters."
            e = {"error": message}
            log_predict.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))
            return jsonify(e), 400

    except Exception as exception:
        e = {'ERROR': str(exception)}
        log_predict.info("Rid:%s; Response:%s", Rid, str(exception))
        return jsonify(e), 500


@app.route("/api/v3/status/<task_id>", methods=['GET'])
@authenticate
def status(task_id):
    """
    status API for intent NER consolidated training
    :param task_id:
    :return: consolidated current status of intent and NER training
    """
    log_status = logging_function("status", "status.log")
    log_status_debug = logging_function("status", "status_debug.log")

    Rid = str(uuid4())
    try:
        if master.keys(task_id):
            param_dict = {"task_id": task_id}
            log_status.info("Rid:%s; Request:%s", Rid, json.dumps(param_dict, ensure_ascii=False))
            data = manage_redis.redis_get(key=task_id, master=master)
            response = data.get('response')
            get_status = Status(config=CONFIG, status=response, master=master, model_info=data, logs=log_status_debug, rid=Rid)
            response = get_status.make_api_calls()
            log_status.info("Rid:%s; Response:%s", Rid, json.dumps(response, ensure_ascii=False))
            return jsonify(response), 200
        else:
            e = {"ERROR": "task_id not found please check and try again"}
            log_status.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))
            return jsonify(e), 400

    except Exception as exception:
        e = {'ERROR': str(exception)}
        log_status.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))
        return jsonify(e), 500


@app.route('/api/v3/training/<task_id>', methods=['DELETE'])
@authenticate
def cancel(task_id):
    """

    :param task_id:
    :return:
    """
    log_cancel = logging_function("cancel", "cancel.log")
    log_cancel_debug = logging_function("cancel", "cancel_debug.log")

    Rid = str(uuid4())
    try:
        if master.keys(task_id):

            param_dict = {"task_id": task_id}
            log_cancel.info("Rid:%s; Request:%s", Rid, json.dumps(param_dict, ensure_ascii=False))
            data = manage_redis.redis_get(key=task_id, master=master)
            response = data.get('response')
            cancel = Cancel(config=CONFIG, cancel=response, model_info=data, master=master, logs=log_cancel_debug, rid=Rid)
            result, code = cancel.make_api_calls()
            log_cancel.info("Rid:%s; Response:%s", Rid, json.dumps(result, ensure_ascii=False))
            return jsonify(result), code

        else:
            e = {"ERROR": "task_id not found please check and try again"}
            log_cancel.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))
            return jsonify(e), 400

    except Exception as exception:
        e = {'ERROR': str(exception)}
        log_cancel.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))
        return jsonify(e), 500


@app.route("/api/v3/training", methods=['POST'])
@authenticate
def training():
    """
    takes input training file and parameters for training a model
    checks if the same model is already in training or not if not puts the new model in training
    :return: returns a task id which will be used to track progress of any training
    """
    log_training = logging_function("training", "training.log")
    log_training_debug = logging_function("training", "training_debug.log")
    Rid = str(uuid4())

    lang, model, algo, callback, fallback, stopwords_remove, syn_form, clean_indicator = utils.get_params(request.args, 'train')
    lang = utils.convert_lang(lang)
    param_dict = utils.create_train_param_dict(lang, model, algo, callback, fallback, stopwords_remove, syn_form, clean_indicator)
    _lang_appropriate = utils.is_lang_appropriate(lang=lang)
    syn_form = None
    if not _lang_appropriate:
        train_ans = {'error': 'language not found please enter en for English or hi for Hindi'}
        return jsonify(train_ans), 400

    log_training.info("Rid:%s; Request:%s", Rid, json.dumps(param_dict, ensure_ascii=False))

    if all(v is not None for v in [lang, model, algo, callback, fallback,
                                   stopwords_remove, clean_indicator]):

        data_folder = utils.create_data_folder()
        model_name = model + '_' + lang
        model_folder = utils.create_folder(model_folder_name=data_folder, model_name=model_name)
        file_present, file_name = utils.save_train_file(request=request, model=model, lang=lang,
                                                            model_folder=model_folder)

        if not file_present:

            train_ans = {'error': 'please upload ' + file_name}
            log_training.info("Rid:%s; Response:%s", Rid, json.dumps(train_ans, ensure_ascii=False))

            return jsonify(train_ans), 400

        else:

            model_key = 'ml_' + model + '_' + lang

            try:

                if master.keys(model_key):
                    data = manage_redis.redis_get(key=model_key, master=master)
                    task_id = data.get('task_id')
                    e = {'ERROR': 'Model is already training, Check the status with task id ' + task_id}
                    log_training.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))
                    return jsonify(e), 400

                else:
                    task_id = str(uuid4())
                    task_data = {'task_id': task_id, 'model': model, 'lang': lang}

                    try:
                        train = Training(redis_master=master, redis_manager=manage_redis, config=CONFIG, model_folder=model_folder, logs=log_training_debug, rid=Rid)
                        train.make_api_calls(lang, algo, model, stopwords_remove, syn_form, False, callback,
                                            fallback)
                        response, code = train.consolidated_response()
                        dict_to_redis = {'model': model, 'lang': lang, 'task_id': task_id, "response": response}
                        task_id_dict = {'task_id': task_id}

                        if code == 200:

                            # train.setup_nfs_operations()
                            manage_redis.redis_insert(key=task_id, dict_to_redis=dict_to_redis, master=master)
                            manage_redis.redis_insert(key=model_key, dict_to_redis=task_id_dict, master=master)
                            polling_task.delay(callback, fallback, task_id)
                            log_training.info("Rid:%s; Response:%s", Rid, json.dumps(task_data, ensure_ascii=False))

                            return jsonify(task_data)

                        else:
                            cancel_training = Cancel(config=CONFIG, model_info=dict_to_redis, cancel=response, master=master,
                                                     logs=log_training_debug, rid=Rid)
                            intent_state = response.get("task_id")
                            log_training.info("Rid:%s; task_id:%s", Rid, str(intent_state))
                            ner_state = response.get("ner")
                            log_training.info("Rid:%s; ner:%s", Rid, json.dumps(ner_state, ensure_ascii=False))
                            cancel_training.cancel_failed_training(intent_state, ner_state)
                            e = {"error": "please check this " + str(response)}
                            resp = {"error": " issue while putting model in training please try again later"}
                            log_training.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))

                            return jsonify(resp), 500

                    except Exception as e:
                        print(e)
                        master.delete(model_key)
                        e = {'ERROR': str(e)}
                        log_training.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))
                        resp = {"error": " issue while putting model in training please try again later: exp 1 "}

                        return jsonify(resp), 500

            except Exception as exception:
                master.delete(model_key)
                print(exception)
                e = {'ERROR': 'This is redis connection error, Please Contact Admin: ' + str(exception)}
                log_training.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))

                return jsonify(e), 500

    else:

        param_list = ['lang', 'model', 'algo', 'callback', 'fallback', 'stopwords_remove', 'syn_form', 'clean_indicator']
        message = "please provide all parameters. required params list %s " % param_list
        e = {"error": message}
        log_training.info("Rid:%s; Response:%s", Rid, json.dumps(e, ensure_ascii=False))

        return jsonify(e), 400


@celery.task(bind=True, base=EnsuredRedisTask)
def polling_task(request, callback, fallback, task_id):

    log_status_debug = logging_function("status", "status_polling_debug.log")

    callback_header = CONFIG.get("callback-fallback").get("headers")

    def check_status_for_callback(result):
        states = []
        intent_state = None
        ner_state = None
        intent = result.get("intent")
        ner = result.get("ner")
        if intent is not None:
            intent_state = intent.get("state")
            states.append(intent_state)
        if ner is not None:
            ner_state = ner.get("state")
            states.append(ner_state)
        if any(i in ['FAILURE'] for i in states):
            log_status_debug.info("Rid:%s; Response :%s", rid, "entered FAILURE STATE: POLLING STOPPED")
            print("result ---->", result)
            cancel_training.cancel_failed_training(intent_state, ner_state)
            fallback_result = utils.fallback_url(fallback, callback_header, model, lang)
            if fallback_result == 'Failed':
                log_status_debug.info("Rid:%s; Response :%s", rid, "issue while calling fallback")
            else:
                log_status_debug.info("Rid:%s; Response :%s", rid, "fallback sent")
                master.delete(model_key)
            result.clear()
            states.clear()
            return True
        elif all(i in ['SUCCESS'] for i in states):
            log_status_debug.info("Rid:%s; Response :%s", rid, "entered SUCCESS STATE: POLLING STOPPED")
            print("result ---->", result)
            callback_result = utils.callback_url(callback, callback_header, model, lang)
            if callback_result == 'Failed':
                log_status_debug.info("Rid:%s; Response :%s", rid, "issue while calling callback")
            else:
                log_status_debug.info("Rid:%s; Response :%s", rid, "callback sent")
                master.delete(model_key)
            result.clear()
            states.clear()
            return True
        elif any(i in ['REVOKED'] for i in states):
            log_status_debug.info("Rid:%s; Response :%s", rid, "entered REVOKED STATE: POLLING STOPPED")
            print("result ---->", result)
            master.delete(model_key)
            result.clear()
            states.clear()
            return True
        else:
            log_status_debug.info("Rid:%s; Response :%s", rid, "polling continues response: " + json.dumps(result))
            states.clear()
            result.clear()
            return False

    rid = str(uuid4())
    data = manage_redis.redis_get(key=task_id, master=master)
    response = data.get('response')
    log_status_debug.info("Rid:%s; task id ----> :%s", rid, task_id)
    log_status_debug.info("Rid:%s; model data ----> :%s", rid, response)
    model = response.get("model")
    lang = response.get("lang")
    model_key = 'ml_' + model + '_' + lang

    cancel_training = Cancel(config=CONFIG, cancel=response, model_info=data, master=master, logs=log_status_debug, rid=rid)
    get_status = Status(config=CONFIG, status=response, master=master, model_info=data, logs=log_status_debug, rid=rid)

    try:

        poll(
            lambda: get_status.make_api_calls(),
            check_success=check_status_for_callback,
            step=60,
            timeout=3600)

    except TimeoutException as e:
        cancel_training.make_api_calls()
        master.delete(model_key)
        log_status_debug.info("Rid:%s; Response:%s", rid, "exception while polling:timeout error" + str(e))
        fallback_res = utils.fallback_url(fallback, callback_header, model, lang)

        if fallback_res == 'Failed':
            log_status_debug.info("Rid:%s; Response :%s", rid, "issue while calling fallback")

        else:
            log_status_debug.info("Rid:%s; Response :%s", rid, "fallback sent")
    except Exception as e:
        cancel_training.make_api_calls()
        master.delete(model_key)
        log_status_debug.info("Rid:%s; Response:%s", rid, "exception while polling" + str(e))
        fallback_res = utils.fallback_url(fallback, callback_header, model, lang)

        if fallback_res == 'Failed':
            log_status_debug.info("Rid:%s; Response:%s", rid, "issue while calling fallback")

        else:

            log_status_debug.info("Rid:%s; Response :%s", rid, "fallback sent")


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=4002, threaded=True)
